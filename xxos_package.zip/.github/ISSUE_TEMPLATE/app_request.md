---
name: App/Package request
about: Suggest an application or package to include in XXOS
title: "[APP] "
labels: enhancement
assignees: ''
---

**App name**
**Description**
**Why should it be included**
**Suggested package/source**
