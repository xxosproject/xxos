# Tor Privacy Setup

Instructions to enable Tor transparent proxy and Whonix gateway.
