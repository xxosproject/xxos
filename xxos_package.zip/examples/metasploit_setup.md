# Metasploit Setup

Use the container in containers/metasploit/ to run Metasploit in an isolated environment.
