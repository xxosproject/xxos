# Crypto Mining Demo

Guides and safety notes for testing mining tools in lab environments.
