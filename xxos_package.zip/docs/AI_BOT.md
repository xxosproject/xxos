# AI Triage Bot

This document explains the offline Hugging Face AI triage bot.
