xxos-agent local assistant stub
Run with: sudo python3 app.py
The assistant is a local stub that will later be extended to run an offline model (Hugging Face/llama.cpp).
It exposes /status and /assist endpoints used by the Web Console.
